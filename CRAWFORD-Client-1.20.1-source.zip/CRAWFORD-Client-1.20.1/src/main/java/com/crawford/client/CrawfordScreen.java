package com.crawford.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class CrawfordScreen extends Screen {
    private static final int BLUE = 0xFF1677E8;
    private static final int YELLOW = 0xFFFFD43B;
    private static final int PANEL = 0xE8171D2B;
    private static final int PANEL_ALT = 0xE8222B3D;

    protected CrawfordScreen() {
        super(Text.literal("CRAWFORD Client"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        int left = Math.max(12, (width - 430) / 2);
        int top = Math.max(12, (height - 270) / 2);
        int right = Math.min(width - 12, left + 430);
        int bottom = Math.min(height - 12, top + 270);

        context.fill(left, top, right, bottom, PANEL);
        context.fill(left, top, right, top + 34, BLUE);
        context.fill(left, top + 34, right, top + 37, YELLOW);
        context.drawTextWithShadow(textRenderer, "CRAWFORD CLIENT", left + 14, top + 12, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "1.20.1  |  FABRIC", right - 112, top + 12, YELLOW);

        int navRight = left + 112;
        context.fill(left + 10, top + 48, navRight, bottom - 12, PANEL_ALT);
        context.drawTextWithShadow(textRenderer, "HOME", left + 22, top + 62, YELLOW);
        context.drawTextWithShadow(textRenderer, "VISUALS", left + 22, top + 88, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "HUD", left + 22, top + 114, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "ABOUT", left + 22, top + 140, 0xFFFFFFFF);

        int contentX = left + 128;
        context.drawTextWithShadow(textRenderer, "WELCOME TO CRAWFORD", contentX, top + 55, YELLOW);
        drawTile(context, contentX, top + 78, "Motion Blur", "Planned feature", BLUE, YELLOW);
        drawTile(context, contentX, top + 126, "Custom HUD", "Planned feature", BLUE, YELLOW);
        drawTile(context, contentX, top + 174, "Karambit Cosmetic", "Planned feature", BLUE, YELLOW);
        context.drawTextWithShadow(textRenderer, "Right Shift  •  Close with ESC", contentX, bottom - 27, 0xFFB9C6D8);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawTile(DrawContext context, int x, int y, String title, String subtitle, int accent, int highlight) {
        context.fill(x, y, x + 276, y + 40, PANEL_ALT);
        context.fill(x, y, x + 3, y + 40, accent);
        context.drawTextWithShadow(textRenderer, title, x + 12, y + 7, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, subtitle, x + 12, y + 22, highlight);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
