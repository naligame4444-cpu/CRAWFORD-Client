CRAWFORD CLIENT - Fabric 1.20.1 starter project

This is SOURCE CODE, not a compiled .jar yet.
It currently implements the client entrypoint and a blue/yellow ClickGUI opened with RIGHT SHIFT.
The Motion Blur, FPS optimization suite, HUD widgets, lobby redesign, and karambit cosmetic are planned UI/features and are NOT implemented yet.

Build requirements:
- Java 17
- Gradle 8.6 (the Fabric Loom plugin will be downloaded by Gradle)
- Internet access for Minecraft/Fabric/Gradle dependencies

Build command (from this folder):
  gradle build

The compiled mod, when successfully built, will be in:
  build/libs/crawford-client-1.20.1-1.0.0.jar

Install on PojavLauncher:
1. Use a Minecraft 1.20.1 Fabric profile.
2. Install Fabric API for 1.20.1 in that profile's mods folder.
3. Copy the compiled crawford-client jar into the same mods folder.

Note: This starter targets Minecraft Java 1.20.1, not 1.20.10 (which is not a Java Edition release).
