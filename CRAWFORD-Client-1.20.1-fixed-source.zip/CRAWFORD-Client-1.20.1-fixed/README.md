# CRAWFORD Client — Minecraft 1.20.1

A starter Fabric client mod for Minecraft Java 1.20.1. Press **Right Shift** in-game to open the blue/yellow CRAWFORD menu.

## Build

Requires JDK 17 and internet access for Gradle dependencies.

```bash
gradle wrapper --gradle-version 8.7
./gradlew build
```

The mod JAR will be in `build/libs/` (choose the JAR without `-sources`). Install it with Fabric Loader and Fabric API for Minecraft 1.20.1.

## Current scope

The working feature in this starter is the Right-Shift menu. Motion blur, FPS modules, custom HUD, and the karambit cosmetic are placeholders and are not implemented yet. This is not a finished full client.
