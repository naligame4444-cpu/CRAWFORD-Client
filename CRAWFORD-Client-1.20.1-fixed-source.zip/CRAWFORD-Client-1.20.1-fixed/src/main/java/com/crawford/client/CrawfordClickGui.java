package com.crawford.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class CrawfordClickGui extends Screen {
    private static final int BLUE = 0xFF1769D2;
    private static final int YELLOW = 0xFFFFD43B;
    private static final int PANEL = 0xEE101827;

    public CrawfordClickGui() {
        super(Text.literal("CRAWFORD CLIENT"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        int left = width / 2 - 145;
        int top = height / 2 - 105;
        int right = left + 290;
        int bottom = top + 210;

        context.fill(left - 2, top - 2, right + 2, bottom + 2, YELLOW);
        context.fill(left, top, right, bottom, PANEL);
        context.fill(left, top, right, top + 30, BLUE);
        context.drawText(textRenderer, "CRAWFORD CLIENT", left + 12, top + 10, 0xFFFFFFFF, true);
        context.drawText(textRenderer, "1.20.1  |  FABRIC", right - 104, top + 10, YELLOW, false);

        drawModule(context, left + 14, top + 48, "MOTION BLUR", "Coming soon");
        drawModule(context, left + 14, top + 83, "FPS BOOST", "Coming soon");
        drawModule(context, left + 14, top + 118, "CUSTOM HUD", "Coming soon");
        drawModule(context, left + 14, top + 153, "KARAMBIT COSMETIC", "Coming soon");

        context.drawText(textRenderer, "RIGHT SHIFT  •  CLOSE MENU", left + 14, bottom - 17, YELLOW, false);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawModule(DrawContext context, int x, int y, String name, String status) {
        context.fill(x, y, x + 262, y + 26, 0xFF202D40);
        context.fill(x, y, x + 3, y + 26, YELLOW);
        context.drawText(textRenderer, name, x + 10, y + 9, 0xFFFFFFFF, true);
        int statusWidth = textRenderer.getWidth(status);
        context.drawText(textRenderer, status, x + 252 - statusWidth, y + 9, YELLOW, false);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
